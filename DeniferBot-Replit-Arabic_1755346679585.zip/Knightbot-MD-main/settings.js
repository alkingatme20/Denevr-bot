const settings = {
  packname: 'دنيفر',
  author: 'Denifer Team',
  botName: "دنيفر",
  botOwner: 'أدمن دنيفر', // Your name
  ownerNumber: '919876543210', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "بوت واتساب خفيف وظريف يساعدك بأوامر كثير — كله بالعربي ✨",
  version: "2.0.8",
};

module.exports = settings;
