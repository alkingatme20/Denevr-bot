
// ====================== إعدادات دنيفر ======================
const { makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys')
const express = require('express')

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('session')
    const { version } = await fetchLatestBaileysVersion()
    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false // إلغاء طباعة QR
    })

    // توليد كود الربط (Pairing Code)
    if (!sock.authState.creds.registered) {
        const code = await sock.requestPairingCode("رقم_واتساب_هنا".replace(/[^0-9]/g, ''))
        console.log(`\nكود ربط واتساب الخاص بك هو: ${code}\n(إسم الجلسة: reta-sea)\nأدخل الكود في واتساب > الأجهزة المرتبطة > إدخال كود\n`)
    }

    sock.ev.on('creds.update', saveCreds)
}

// سيرفر ويب صغير لـ Replit + UptimeRobot
const app = express()
app.get('/', (req, res) => {
    res.send('دنيفر شغال ✅')
})
app.listen(3000, () => console.log('✅ السيرفر شغال على المنفذ 3000'))

startBot()
